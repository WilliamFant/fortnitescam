# #pretty much just have to code this out so it will make a question-air into prompts for the ai

import openai

# Set up the OpenAI API client
openai.api_key = "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"

# Set up the model and prompt
model_engine = "text-davinci-003"

# # ? Do you currently have a website?
# # *If yes, what do you like/dislike about your current website?
# # *What is the purpose of your website? (e.g. to sell products, to showcase your portfolio, to provide information about your business, etc.)
# # *Who is your target audience?
# # *What is the unique value proposition of your business?
# # !Who are your competitors?
# # *What sets you apart from your competitors?
# # *What features do you want on your website?
# # ?Do you have any specific design preferences?
# # ?Do you have a logo and branding in place?
# # ?Do you have a preferred color scheme?
# # *What is your budget for the website?
# # !What is your timeline for the website?
# # ?Do you have any existing content (text, images, videos) that you want to use on the website?
# # ?Will you need help with creating content for the website?
# # ?Will you need e-commerce functionality on the website?
# # ?Do you need a blog section on the website?
# # ?Will the website require integration with any third-party tools or services?
# # ?Will the website need to be optimized for search engines (SEO)?
# # !Will the website need to be mobile-friendly and responsive?
# # ?Do you need a contact form or any other types of forms on the website?
# # ?Do you have any social media profiles that you want to link to the website?
# # !Will you need website hosting and maintenance services?
# # !Do you have any website security concerns?
# # ?Will you need a website privacy policy and terms of use?
# # ?Will the website require any custom functionality or programming?
# # ?Will you need a content management system (CMS) for the website?
# # ?Will the website require any special accessibility features?
# # !Do you have any preferred web development platforms or technologies?
# # ?Will you need help with website promotion and marketing?

# q1 = bool(int(input("Do you have a specific color scheme in mind for your website?")))
# q2 = bool(int(input("Do you have a logo that you would like to use on your website?")))
# q3 = bool(int(input("Do you have a website domain name registered already?")))
# q4 = bool(int(input("Do you have any specific fonts in mind for your website?")))
# q5 = bool(int(input("Do you have any specific images or graphics you would like to use on your website?")))
# q6 = bool(int(input("Do you have any specific page titles or headings you would like to use?")))
# q7 = bool(int(input("Do you have any specific page layouts in mind for your website?")))
# q8 = bool(int(input("Do you have any specific page content already written?")))
# q9 = bool(int(input("Do you want to include a blog on your website?")))
# q10 = bool(int(input("Do you want to include an e-commerce store on your website?")))
# q11 = bool(int(input("Do you want to include a contact form on your website?")))
# q12 = bool(int(input("Do you want to include social media icons on your website?")))
# q13 = bool(int(input("Do you want to include a newsletter sign-up form on your website?")))
# q14 = bool(int(input("Do you want to include a search bar on your website?")))
# q15 = bool(int(input("Do you want to include a navigation menu on your website?")))
# q16 = bool(int(input("Do you want to include a slider or carousel on your website?")))
# q17 = bool(int(input("Do you want to include a video on your website?")))
# q18 = bool(int(input("Do you want to include a photo gallery on your website?")))
# q19 = bool(int(input("Do you want to include a testimonials section on your website?")))
# q20 = bool(int(input("Do you want to include a team members section on your website?")))
# q21 = bool(int(input("Do you want to include a portfolio section on your website?")))
# q22 = bool(int(input("Do you want to include a FAQ section on your website?")))
# q23 = bool(int(input("Do you want to include a privacy policy or terms of use page on your website?")))
# q24 = bool(int(input("Do you want your website to be mobile-responsive?")))
# q25 = bool(int(input("Do you want your website to be optimized for search engines?")))
# q26 = bool(int(input("Do you want your website to load quickly?")))
# q27 = bool(int(input("Do you want to include a live chat feature on your website?")))
# q28 = bool(int(input("Do you want to include a calendar or scheduling feature on your website?")))
# q29 = bool(int(input("Do you want to include a map or location feature on your website?")))
# q30 = bool(int(input("Do you want to include a newsletter or email marketing feature on your website?")))

questions = [
  "What is the purpose of the website?",
  "Who is the target audience for the website?",
  "What are the key features or functionalities that the website should have?",
  "What is the timeline for developing and launching the website?",
  "What is the budget for developing and maintaining the website?",
  "What are the design and branding guidelines for the website?",
  "What are the technical requirements for the website?",
  "What are the security and privacy requirements for the website?",
  "What are the legal requirements for the website?",
  "What are the accessibility requirements for the website?",
  "What are the SEO requirements for the website?",
  "What are the analytics and tracking requirements for the website?",
  "What are the hosting and server requirements for the website?",
  "What are the content management requirements for the website?",
  "What are the e-commerce requirements for the website?",
  "What are the social media integration requirements for the website?",
  "What are the mobile responsiveness requirements for the website?",
  "What are the performance and speed requirements for the website?",
  "What are the testing and QA requirements for the website?",
  "What are the backup and disaster recovery requirements for the website?",
  "What are the maintenance and support requirements for the website?",
  "What are the payment gateway and SSL requirements for the website?",
  "What are the authentication and authorization requirements for the website?",
  "What are the data storage and management requirements for the website?",
  "What are the email marketing and newsletter requirements for the website?",
  "What are the user engagement and retention requirements for the website?",
  "What are the training and documentation requirements for the website?",
  "What are the integration and interoperability requirements for the website?",
  "What are the project management and communication requirements for the website?"
]

# Prompt the user to answer each question
for i, question in enumerate(questions):
    answer = input(f"{i+1}. {question} ")

    prompt = answer

    # Generate a response
    completion = openai.Completion.create(
        engine=model_engine,
        prompt=prompt,
        max_tokens=1024,
        n=1,
        stop=None,
        temperature=0.5,
    )

    response = completion.choices[0].text
    print(response)
